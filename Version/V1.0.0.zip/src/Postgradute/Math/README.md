---
title: 数学
index: false
icon: https://yong-gan-niu-niu-1311841992.cos.ap-beijing.myqcloud.com/images/%E6%95%B0%E5%AD%A6%EF%BC%8C%E7%9B%B4%E5%B0%BA.svg
category:
  - Postgradute
  - Math
  - README
---


## 数学

- [数学_01](math_01.md)
- [数学_02](math_02.md)

