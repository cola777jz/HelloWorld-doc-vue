---
title: 多表映射和动态语句
order: 2
category:
  - Skills
  - HelloMyBatis
  - MD
---

## 三、MyBatis 多表映射

### 3.1 多表映射概念



### 3.2 对一映射



### 3.3 对多映射



### 3.4 多表映射总结



## 四、MyBatis 动态语句

### 4.1 动态语句需求和简介



### 4.2 if 和 where 标签



### 4.3 set 标签



### 4.4 trim 标签



### 4.5 choose 、when 和 otherwise 标签



### 4.6 foreach 标签


### 4.7 sql 片段





## 五、MyBatis 高级拓展

### 5.1 Mapper 批量映射优化



### 5.2 插件和分页插件 PageHelper



### 5.3 逆向工程和 MyBatisX 插件