---
title: 基本入门 CRUD
order: 1
category:
  - Skills
  - HelloMyBatissPlus
  - MD
---

## 一、MyBatisPlus QuickStart

### 1.1 数据库准备

现有一张 User 表，其表结构如下：

| id   | name   | age  | email                                           |
| ---- | ------ | ---- | ----------------------------------------------- |
| 1    | Jone   | 18   | [test1@baomidou.com](mailto:test1@baomidou.com) |
| 2    | Jack   | 20   | [test2@baomidou.com](mailto:test2@baomidou.com) |
| 3    | Tom    | 28   | [test3@baomidou.com](mailto:test3@baomidou.com) |
| 4    | Sandy  | 21   | [test4@baomidou.com](mailto:test4@baomidou.com) |
| 5    | Billie | 24   | [test5@baomidou.com](mailto:test5@baomidou.com) |

- schema 脚本

```sql
DROP TABLE IF EXISTS user;

CREATE TABLE user
(
    id BIGINT(20) NOT NULL COMMENT '主键ID',
    name VARCHAR(30) NULL DEFAULT NULL COMMENT '姓名',
    age INT(11) NULL DEFAULT NULL COMMENT '年龄',
    email VARCHAR(50) NULL DEFAULT NULL COMMENT '邮箱',
    PRIMARY KEY (id)
);

```

- data 脚本

```sql
DELETE FROM user;

INSERT INTO user (id, name, age, email) VALUES
                                            (1, 'Jone', 18, 'test1@baomidou.com'),
                                            (2, 'Jack', 20, 'test2@baomidou.com'),
                                            (3, 'Tom', 28, 'test3@baomidou.com'),
                                            (4, 'Sandy', 21, 'test4@baomidou.com'),
                                            (5, 'Billie', 24, 'test5@baomidou.com');

```

### 1.2 创建 boot 工程

<img src="https://yong-gan-niu-niu-1311841992.cos.ap-beijing.myqcloud.com/images/image-20230915222350294.png" alt="image-20230915222350294" style="zoom:67%;" />

- 引入依赖

```xml
    <dependencies>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
        </dependency>
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-boot-starter</artifactId>
            <version>3.5.3.2</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

```

- 实体类

```java
@Data
public class User {
    private Long id;
    private String name;
    private Integer age;
    private String email;
}

```

- mapper

```java
@Mapper
public interface UserMapper extends BaseMapper<User> {

}
```



### 1.3 配置信息

```yaml
spring:
    datasource:
        driver-class-name: com.mysql.cj.jdbc.Driver
        url: jdbc:mysql://localhost:3306/mybatis-example
        username: root
        password: root
    sql:
        init:
            mode: always
            schema-locations: classpath:sql/schema.sql
            data-locations: classpath:sql/data.sql
```

### 1.4 Enjoy it ~

```java
    @Test
    void testSelectById() {
        User user = userMapper.selectById(1);
        System.out.println(user);
    }
```



<img src="https://yong-gan-niu-niu-1311841992.cos.ap-beijing.myqcloud.com/images/image-20230915222714664.png" alt="image-20230915222714664" style="zoom:67%;" />

### 1.5 测试

```java
@SpringBootTest
class UserMapperTest {

    @Autowired
    private UserMapper userMapper;

    @Test
    public void testSelect() {
        System.out.println(("----- selectAll method test ------"));
        List<User> userList = userMapper.selectList(null);
        Assert.isTrue(5 == userList.size(), "");
        userList.forEach(System.out::println);
    }

    @Test
    void testSelectById() {
        User user = userMapper.selectById(1);
        System.out.println(user);
    }
}
```

<img src="https://yong-gan-niu-niu-1311841992.cos.ap-beijing.myqcloud.com/images/image-20230915222803104.png" alt="image-20230915222803104" style="zoom:67%;" />

## 二、MyBatisPlus 核心功能

### 2.1 基于 Mapper 接口 CRUD

通用 CRUD 封装 [BaseMapper](https://gitee.com/baomidou/mybatis-plus/blob/3.0/mybatis-plus-core/src/main/java/com/baomidou/mybatisplus/core/mapper/BaseMapper.java?spm=wolai.workspace.0.0.330e2306K5MWaO&file=BaseMapper.java)
接口， Mybatis-Plus 启动时自动解析实体表关系映射转换为 Mybatis 内部对象注入容器! 内部包含常见的单表操作！



#### 2.1.1 INSERT 方法

| 类型 | 参数名 | 描述     |
| ---- | ------ | -------- |
| T    | entity | 实体对象 |

#### 2.1.2 DELETE 方法

| 类型                                 | 参数名    | 描述                                 |
| ------------------------------------ | --------- | ------------------------------------ |
| `Wrapper<T>`                         | wrapper   | 实体对象封装操作类（可以为 null）    |
| `Collection<? extends Serializable>` | idList    | 主键 ID 列表(不能为 null 以及 empty) |
| Serializable                         | id        | 主键 ID                              |
| `Map<String, Object>`                | columnMap | 表字段 map 对象                      |



#### 2.1.3 UPDATE 方法

| 类型         | 参数名        | 描述                                                         |
| ------------ | ------------- | ------------------------------------------------------------ |
| T            | entity        | 实体对象 (set 条件值,可为 null)                              |
| `Wrapper<T>` | updateWrapper | 实体对象封装操作类（可以为 null,里面的 entity 用于生成 where 语句） |

#### 2.1.4 SELECT 方法

| 类型                                 | 参数名       | 描述                                     |
| ------------------------------------ | ------------ | ---------------------------------------- |
| Serializable                         | id           | 主键 ID                                  |
| `Wrapper<T>`                         | queryWrapper | 实体对象封装操作类（可以为 null）        |
| `Collection<? extends Serializable>` | idList       | 主键 ID 列表(不能为 null 以及 empty)     |
| `Map<String, Object>`                | columnMap    | 表字段 map 对象                          |
| `IPage<T>`                           | page         | 分页查询条件（可以为 RowBounds.DEFAULT） |


#### 2.1.5 自定义和多表映射

mybatis-plus 的默认 mapperxml 位置

```yaml
mybatis-plus: ## mybatis-plus的配置
  ## 默认位置 private String[] mapperLocations = new String[]{"classpath*:/mapper/**/*.xml"};    
  mapper-locations: classpath:/mapper/*.xml
```

自定义mapper方法：

```java
public interface UserMapper extends BaseMapper<User> {

    //正常自定义方法！
    //可以使用注解@Select或者mapper.xml实现
    List<User> queryAll();
}
```




基于mapper.xml实现：

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "https://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!-- namespace = 接口的全限定符 -->
<mapper namespace="com.atguigu.mapper.UserMapper">

   <select id="queryAll" resultType="user" >
       select * from user
   </select>
</mapper>
```



### 2.2 基于 Service 接口 CRUD



#### 2.2.1 对比 Mapper 接口 CRUD 的区别

#### 2.2.2 使用 IService 接口方式

#### 2.2.3 CRUD 方法介绍



### 2.3 分页查询的实现



### 2.4 条件构造器使用



#### 2.4.1 条件构造器的作用

#### 2.4.2 条件构造器继承结构

#### 2.4.3 基于 QueryWrapper 组装条件

#### 2.4.4 基于 UpdateWrapper 组装条件

#### 2.4.5 基于 LambdaQueryWrapper 组装条件

#### 2.4.6 基于 LambdaUpdateWrapper 组装条件



### 2.5 核心注解使用

