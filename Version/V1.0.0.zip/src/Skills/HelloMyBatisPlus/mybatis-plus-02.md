---
title: MyBatisPlus 高级拓展
order: 2
category:
  - Skills
  - HelloMyBatisPlus
  - MD
---

## 三、MyBatisPlus 高级扩展

### 3.1 逻辑删除实现

### 3.2 乐观锁实现

#### 3.2.1 悲观锁和乐观锁场景和介绍

#### 3.2.2 使用 MyBatisPlus 乐观锁



### 3.3 防全表更新和删除

## 四、MyBatisPlus 代码生成器

### 4.1 MyBatisX 插件逆向工程

### 4.2 MyBatisX 快速代码生成