---
title: 技术类 🧑‍💻🤑
index: false
icon: https://yong-gan-niu-niu-1311841992.cos.ap-beijing.myqcloud.com/images/%E6%8A%80%E5%B7%A7.svg
category:
  - Skills
  - README
---

- [Java 8 新特性概览](HelloJava8/)
- [Lombok 🌶️🌶️🌶️](HelloLombok/)
- [Maven 的使用](HelloMaven/)
- [MyBatis 教程](HelloMyBatis/)
- [MyBatisPlus 教程](HelloMyBatisPlus/)

